package edu.escuelaing.arep;

public class Operacion {
    /**
     * Clase operacion
     * @author David PZ
     * CC. 1193427928
     * Operaciones : sin, sqrt
     */

    public static double sin(double value){
        return Math.sin(value);
    }

    public static double sqrt(double value){
        return Math.sqrt(value);
    }
}
